/*
* Name: 
* Datum:
* Mtr:
* zusammenfassung unsere programm
*/
#include "cPunkt.h"

int main() {
	cPunkt p1; // es wird hier eine punkt erstellt dank der konstruktor
	cout << "vorgabe Wert wird ausgegeben." << endl;
	p1.ausgabe();

	cPunkt p2(5.0, 6);
	cout << "selbst geschriebene Wert wird ausgegeben." << endl;
	p2.ausgabe();

	cPunkt p3;
	p3.eingabe();
	cout << "eingabe von user" << endl;
	p3.ausgabe();


	return 0;
}