#include "cPunkt.h"

cPunkt::cPunkt(double x_in, double y_in)
{
	x = x_in;
	y = y_in;
}

void cPunkt::eingabe()
{
	cout << "geben Sie bitte ein xKoo ein: " << endl;
	cin >> x;

	cout << "geben Sie bitte ein yKoo ein: " << endl;
	cin >> y;
}


void cPunkt::ausgabe()
{
	cout << "X Koordinaten: " << x << endl;
	cout << "Y Koordinaten: " << y << endl;
	
}
