/*
* Name: 
* Datum:
* Mtr:
* zusammenfassung unsere programm
*/
#include "cPunkt.h"
#include "cDreieck.h"

int main() {
	cPunkt p1; // es wird hier eine punkt erstellt dank der konstruktor
	cout << "vorgabe Wert wird ausgegeben." << endl;
	p1.ausgabe();

	cPunkt p2(5.0, 6);
	cout << "selbst geschriebene Wert wird ausgegeben." << endl;
	p2.ausgabe();

	cPunkt p3;
	p3.eingabe();
	cout << "eingabe von user" << endl;
	p3.ausgabe();

	cout << ".................ab hier dreieck................" << endl;
	cDreieck d1;
	d1.ausgabe();

	cout << "ausgabe von eingegebene dreieck." << endl;
	cDreieck d2(cPunkt(34.4, 45.4), cPunkt(45.4, 4.4), cPunkt(34.4, 5.4));
	d2.ausgabe();

	return 0;
}