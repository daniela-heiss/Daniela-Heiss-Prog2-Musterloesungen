#pragma once
using namespace std;
#include <iostream>
class cPunkt
{
private:
	double x, y;
public:
	cPunkt(double x_in = 2.0, double y_in = 3.5);
	void eingabe();
	void ausgabe();

	double getX();
	double getY();

	friend cPunkt add(cPunkt p1, cPunkt p2);
	friend cPunkt sub(cPunkt p1, cPunkt p2);
};

