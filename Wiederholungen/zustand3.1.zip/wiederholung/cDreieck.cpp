#include "cDreieck.h"

cDreieck::cDreieck(cPunkt p1_in, cPunkt p2_in, cPunkt p3_in)
{
	p1 = p1_in;
	p3 = p3_in;
	p2 = p2_in;
}

void cDreieck::ausgabe() {
	cout << "punkt1: " << endl;
	p1.ausgabe();

	cout << "punkt2: " << endl;
	p2.ausgabe();

	cout << "punkt2: " << endl;
	p3.ausgabe();
	
}


