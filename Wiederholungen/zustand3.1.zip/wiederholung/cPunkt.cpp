#include "cPunkt.h"

cPunkt::cPunkt(double x_in, double y_in)
{
	x = x_in;
	y = y_in;
}

void cPunkt::eingabe()
{
	cout << "geben Sie bitte ein xKoo ein: " << endl;
	cin >> x;

	cout << "geben Sie bitte ein yKoo ein: " << endl;
	cin >> y;
}


void cPunkt::ausgabe()
{
	cout << "X Koordinaten: " << x << endl;
	cout << "Y Koordinaten: " << y << endl;
	
}

double cPunkt::getX()
{
	return x;
}

double cPunkt::getY()
{
	return y;
}

cPunkt add(cPunkt p1, cPunkt p2)
{

	return cPunkt(p1.x + p2.x, p1.y + p2.y); // erste schreibtweise nur mit den Return direkt.
}

// hier untern folgt den zweite Schreibweise
cPunkt sub(cPunkt p1, cPunkt p2) {
	cPunkt helfer;		// helfer hilf uns von cPunkt zu speichern
	helfer.x = p1.x - p2.x; // man muss der helfer sagen welche koordinate der nemmen muss.
	helfer.y = p1.y - p2.y; // somit wird sowohl der x koordinate als auch den y koordinaten in helfer gespeichert.
	return helfer;
}


