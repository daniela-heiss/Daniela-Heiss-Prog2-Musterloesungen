/*	u09c - Subskription Jukebox
 *	30.05.2021, editiert am 16.12.2022
 *  Daniela Heiss
 */

#include "cJukebox.h"

int main() {

	cJukebox jukebox1;
	while (jukebox1.operator[](cin) != -1);

	return 0;
}

